package com.mindcontrol.app

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.Editable
import android.text.InputType
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Mind Control - cliente Android para el ESP8266 ESP-01 (port de mind_control.py).
 *
 * Protocolo UDP (el mismo del firmware):
 *   "X<n>"  n = -100..100   velocidad / sentido del motor
 *   "D"                     alterna el modo debug del ESP (responde "Debug ON/OFF")
 */
class MainActivity : Activity() {

    companion object {
        const val DEFAULT_TARGET = "192.168.4.1:10000"
    }

    // ---- estado (igual que la version de escritorio)
    private val handler = Handler(Looper.getMainLooper())
    private val link = UdpLink()
    private var power = 100
    private var verified = false
    private var verbose = false
    private var connecting = false
    private var lastSent: Int? = null
    private var lastTx = 0L
    private var outX = 0
    private var warnT = 0L
    private var tPrev = SystemClock.elapsedRealtime()

    // ---- red: red WiFi del ESP (sin internet)
    @Volatile private var wifiNet: Network? = null
    private val cm by lazy { getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager }
    private val netCb = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            wifiNet = network
        }

        override fun onLost(network: Network) {
            if (wifiNet == network) wifiNet = null
        }
    }

    // ---- vistas
    private lateinit var target: EditText
    private lateinit var btnConnect: PanelButton
    private lateinit var btnDebug: PanelButton
    private lateinit var lamp: LampView
    private lateinit var gauge: GaugeView
    private lateinit var joy: JoystickView
    private lateinit var slider: PowerSliderView
    private lateinit var powerText: TextView
    private lateinit var console: TextView
    private lateinit var consoleScroll: ScrollView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).roundToInt()

    // ================================================================ ciclo

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(buildUi())

        link.onRx = { msg -> handler.post { onRx(msg) } }
        link.onError = { msg ->
            handler.post {
                log("Error de envio: $msg", ERR)
                disconnect(silent = true)
            }
        }
        requestWifi()

        log("Mind Control listo. Conectate al WiFi 'MindControl_AP'.", INK)
        log("IP del ESP en modo AP: 192.168.4.1 (puerto 10000).", DIM)
        log("Zona muerta del firmware: |x| < 5 deja el motor libre.", DIM)

        handler.postDelayed(netTick, 50)
        handler.postDelayed(animTick, 33)
    }

    override fun onPause() {
        super.onPause()
        // seguridad: al salir de la app el motor queda libre
        joy.reset()
        if (link.connected) {
            link.send("X0")
            lastSent = 0
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if (link.connected) {
            link.send("X0")
            link.send("X0")             // por si se pierde un paquete
            link.close()
        }
        try {
            cm.unregisterNetworkCallback(netCb)
        } catch (e: Exception) {
            // ya estaba desregistrado
        }
        super.onDestroy()
    }

    // ================================================================ interfaz

    private fun buildUi(): View {
        val root = ScrollView(this).apply {
            setBackgroundColor(CHASSIS)
            isFillViewport = true
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(18))
        }
        root.addView(col, LinearLayout.LayoutParams(-1, -2))

        // titulo + lampara
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(label("Mind Control", 22f, INK, true), LinearLayout.LayoutParams(0, -2, 1f))
        lamp = LampView(this)
        head.addView(lamp, LinearLayout.LayoutParams(dp(150), dp(28)))
        col.addView(head, LinearLayout.LayoutParams(-1, -2))
        col.addView(label("Enlace UDP a ESP8266 ESP-01 - control de motor", 11f, DIM, false))

        // destino + conexion
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        target = EditText(this).apply {
            setText(DEFAULT_TARGET)
            setTextColor(INK)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            typeface = Typeface.MONOSPACE
            gravity = Gravity.CENTER
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_DONE
            highlightColor = AMBER
            background = GradientDrawable().apply {
                cornerRadius = 12f
                setColor(INSET)
                setStroke(2, EDGE)
            }
            setPadding(dp(8), 0, dp(8), 0)
        }
        row.addView(target, LinearLayout.LayoutParams(0, dp(46), 1f))
        btnConnect = PanelButton(this, "Connect", AMBER, action = { toggleConnect() })
        row.addView(btnConnect, LinearLayout.LayoutParams(dp(120), dp(46)).apply {
            leftMargin = dp(8)
        })
        col.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })

        // galvanometro
        gauge = GaugeView(this)
        col.addView(gauge, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })

        // joystick + power level
        val mid = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        joy = JoystickView(this, onChange = { push() }, onGrab = { onGrab() })
        mid.addView(joy, LinearLayout.LayoutParams(0, -2, 1f))

        val side = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        side.addView(label("POWER LEVEL", 10f, DIM, true))
        val readout = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                cornerRadius = 8f
                setColor(INSET)
                setStroke(2, EDGE)
            }
        }
        powerText = TextView(this).apply {
            text = "100"
            setTextColor(AMBER)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 34f)
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        }
        readout.addView(powerText)
        readout.addView(TextView(this).apply {
            text = "%"
            setTextColor(mix(INSET, AMBER, .6f))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        })
        side.addView(readout, LinearLayout.LayoutParams(-1, dp(58)).apply { topMargin = dp(4) })
        slider = PowerSliderView(this, power) { v -> onPower(v) }
        side.addView(slider, LinearLayout.LayoutParams(dp(100), dp(250)).apply {
            topMargin = dp(6)
        })
        mid.addView(side, LinearLayout.LayoutParams(dp(112), -2))
        col.addView(mid, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })

        // paro
        val force = PanelButton(this, "Force  Send 0", REV, action = { forceStop() })
        col.addView(force, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(12) })

        // consola
        console = TextView(this).apply {
            setTextColor(INK)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = Typeface.MONOSPACE
            setPadding(dp(8), dp(6), dp(8), dp(6))
            setText("", TextView.BufferType.EDITABLE)
        }
        consoleScroll = ScrollView(this).apply {
            background = GradientDrawable().apply {
                cornerRadius = 10f
                setColor(INSET)
                setStroke(2, EDGE)
            }
            setOnTouchListener { v, _ ->
                v.parent?.requestDisallowInterceptTouchEvent(true)
                false
            }
        }
        consoleScroll.addView(console)
        col.addView(consoleScroll, LinearLayout.LayoutParams(-1, dp(170)).apply {
            topMargin = dp(12)
        })

        // botones de depuracion
        val dbg = LinearLayout(this)
        btnDebug = PanelButton(this, "Debug", INK, toggle = true, action = { toggleVerbose() })
        val btnUdp = PanelButton(this, "Debug UDP", AMBER, action = { debugUdp() })
        val btnClear = PanelButton(this, "Clear", INK, action = { clearConsole() })
        val bl = { LinearLayout.LayoutParams(0, dp(44), 1f).apply { rightMargin = dp(6) } }
        dbg.addView(btnDebug, bl())
        dbg.addView(btnUdp, bl())
        dbg.addView(btnClear, LinearLayout.LayoutParams(0, dp(44), 1f))
        col.addView(dbg, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        col.addView(label("v2.1 - port a Android", 10f, DIM, false).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, 0)
        })
        return root
    }

    private fun label(t: String, sp: Float, color: Int, bold: Boolean) = TextView(this).apply {
        text = t
        setTextColor(color)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    // ================================================================ consola

    private val ERR = Color.parseColor("#ff6b57")
    private val timeFmt = SimpleDateFormat("HH:mm:ss  ", Locale.US)

    private fun log(msg: String, color: Int = INK) {
        val stamp = timeFmt.format(Date())
        val line = SpannableString(stamp + msg + "\n")
        line.setSpan(ForegroundColorSpan(DIM), 0, stamp.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        line.setSpan(ForegroundColorSpan(color), stamp.length, line.length,
            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        console.append(line)
        val ed = console.text as? Editable
        if (ed != null && ed.length > 16000) ed.delete(0, 4000)
        consoleScroll.post { consoleScroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun clearConsole() {
        (console.text as? Editable)?.clear()
    }

    // ================================================================ conexion

    private fun requestWifi() {
        try {
            val req = NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .build()
            cm.requestNetwork(req, netCb)
        } catch (e: Exception) {
            log("No se pudo pedir la red WiFi: ${e.message}", DIM)
        }
    }

    private fun toggleConnect() {
        if (link.connected) disconnect() else connect()
    }

    private fun connect() {
        if (connecting) return
        val raw = target.text.toString().trim()
        val parsed: Pair<String, Int>? = try {
            val i = raw.lastIndexOf(':')
            val h = (if (i >= 0) raw.substring(0, i) else raw).trim().ifEmpty { "192.168.4.1" }
            val ps = if (i >= 0) raw.substring(i + 1).trim() else ""
            val p = if (ps.isNotEmpty()) ps.toInt() else 10000
            require(p in 1..65535)
            Pair(h, p)
        } catch (e: Exception) {
            null
        }
        if (parsed == null) {
            log("Destino invalido. Usa el formato IP:puerto.", ERR)
            return
        }
        val (host, port) = parsed
        val net = wifiNet
        if (net == null) log("Aviso: sin red WiFi detectada; ¿estas en MindControl_AP?", DIM)
        connecting = true
        Thread({
            try {
                link.open(host, port, net)
                handler.post { onOpened(host, port) }
            } catch (e: Exception) {
                handler.post {
                    connecting = false
                    log("No se pudo abrir el socket: ${e.message}", ERR)
                }
            }
        }, "udp-open").start()
    }

    private fun onOpened(host: String, port: Int) {
        connecting = false
        verified = false
        lamp.state = 1
        btnConnect.setLabel("Disconnect", REV)
        log("Enlace UDP abierto hacia $host:$port", FWD)
        log("UDP no confirma entregas: pulsa Debug UDP para verificar.", DIM)
        sendX(0, quiet = true)          // arranca con el motor libre
    }

    private fun disconnect(silent: Boolean = false) {
        if (link.connected) {
            link.send("X0")
            link.close()
        }
        lastSent = null
        lamp.state = 0
        btnConnect.setLabel("Connect", AMBER)
        if (!silent) log("Enlace cerrado.", AMBER)
    }

    private fun onRx(text: String) {
        log("<- $text", AMBER)
        if (!verified && link.connected) {
            verified = true
            lamp.state = 2
            log("El ESP responde: enlace verificado.", FWD)
        }
    }

    // ================================================================ envio

    private fun currentX(): Int {
        val axis = if (joy.dragging) joy.axisX else 0f
        return (axis * power).roundToInt().coerceIn(-100, 100)
    }

    private fun sendX(x: Int, quiet: Boolean = false) {
        val prev = lastSent
        if (!link.send("X$x")) return
        lastSent = x
        lastTx = SystemClock.elapsedRealtime()
        if (quiet) return
        if (verbose) log("-> X$x", FWD)
        else if (x == 0 && prev != null && prev != 0) log("X0  motor libre", DIM)
        else if (x != 0 && (prev == null || prev == 0)) log("-> X$x", FWD)
    }

    private fun push() {
        if (!link.connected) return
        val x = currentX()
        val now = SystemClock.elapsedRealtime()
        if (x != lastSent) {
            if (x == 0 || now - lastTx >= 30) sendX(x)
        } else if (x != 0 && now - lastTx >= 500) {
            sendX(x, quiet = true)      // refresco ante paquetes perdidos
        }
    }

    private fun forceStop() {
        joy.reset()
        if (link.connected) {
            sendX(0, quiet = true)
            log("Force: X0 enviado.", AMBER)
        } else {
            log("Force: sin conexion, nada que enviar.", AMBER)
        }
    }

    private fun debugUdp() {
        if (!link.connected) {
            log("Conecta primero.", AMBER)
            return
        }
        if (link.send("D")) log("-> D  (alterna debug en el ESP)", FWD)
    }

    private fun toggleVerbose() {
        verbose = btnDebug.active
        log("Debug local ${if (verbose) "activado" else "desactivado"}.", DIM)
    }

    private fun onPower(v: Int) {
        power = v
        powerText.text = v.toString()
        push()
    }

    private fun onGrab() {
        val now = SystemClock.elapsedRealtime()
        if (!link.connected && now - warnT > 4000) {
            warnT = now
            log("Sin conexion: el control no envia nada. Pulsa Connect.", AMBER)
        }
    }

    // ================================================================ bucles

    private val netTick = object : Runnable {
        override fun run() {
            outX = currentX()
            push()
            handler.postDelayed(this, 50)
        }
    }

    private val animTick = object : Runnable {
        override fun run() {
            val now = SystemClock.elapsedRealtime()
            val dt = min((now - tPrev) / 1000f, 0.1f)
            tPrev = now
            gauge.advance(dt, outX)
            lamp.invalidate()
            handler.postDelayed(this, 33)
        }
    }
}
