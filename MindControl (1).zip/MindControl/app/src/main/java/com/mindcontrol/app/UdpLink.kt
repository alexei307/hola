package com.mindcontrol.app

import android.net.Network
import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.SocketTimeoutException
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Un unico socket UDP: el ESP responde al puerto de origen del paquete.
 * Los envios van por un hilo propio (Android prohibe red en el hilo principal)
 * y se mantienen en orden.
 */
class UdpLink {

    var onRx: (String) -> Unit = {}
    var onError: (String) -> Unit = {}

    @Volatile private var sock: DatagramSocket? = null
    @Volatile private var dest: InetSocketAddress? = null
    private var stopFlag = AtomicBoolean(true)

    private val tx = Executors.newSingleThreadExecutor { r ->
        Thread(r, "udp-tx").apply { isDaemon = true }
    }

    val connected: Boolean get() = sock != null

    /** Bloqueante (resuelve el host): llamar desde un hilo de fondo. */
    @Throws(IOException::class)
    fun open(host: String, port: Int, network: Network?) {
        val addr = InetAddress.getByName(host)
        val s = DatagramSocket()
        try {
            // Sin esto, Android puede mandar el trafico por datos moviles
            // porque el WiFi del ESP no tiene internet.
            network?.bindSocket(s)
            s.soTimeout = 250
        } catch (e: IOException) {
            s.close()
            throw e
        }
        val stop = AtomicBoolean(false)
        stopFlag = stop
        dest = InetSocketAddress(addr, port)
        sock = s

        Thread({
            val buf = ByteArray(512)
            val pkt = DatagramPacket(buf, buf.size)
            while (!stop.get()) {
                try {
                    pkt.length = buf.size
                    s.receive(pkt)
                    onRx(String(pkt.data, 0, pkt.length, Charsets.UTF_8).trim())
                } catch (e: SocketTimeoutException) {
                    // seguir esperando
                } catch (e: IOException) {
                    break
                }
            }
        }, "udp-rx").apply { isDaemon = true }.start()
    }

    /** Encola un paquete. Devuelve false si no hay enlace abierto. */
    fun send(text: String): Boolean {
        val s = sock ?: return false
        val d = dest ?: return false
        val st = stopFlag
        val data = text.toByteArray(Charsets.US_ASCII)
        tx.execute {
            try {
                s.send(DatagramPacket(data, data.size, d))
            } catch (e: Exception) {
                if (!st.get()) onError(e.message ?: e.javaClass.simpleName)
            }
        }
        return true
    }

    /** Cierra despues de los envios ya encolados (asi el ultimo X0 sale). */
    fun close() {
        val s = sock ?: return
        sock = null
        stopFlag.set(true)
        tx.execute {
            try {
                s.close()
            } catch (e: Exception) {
                // ignorar
            }
        }
    }
}
