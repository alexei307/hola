package com.mindcontrol.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.os.SystemClock
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.TextView
import java.util.Locale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

// ---------------------------------------------------------------- paleta

val CHASSIS = Color.parseColor("#0f1317")
val PANEL = Color.parseColor("#171d23")
val INSET = Color.parseColor("#0b0f13")
val EDGE = Color.parseColor("#2b343d")
val INK = Color.parseColor("#d8d2c2")
val DIM = Color.parseColor("#7b858f")
val AMBER = Color.parseColor("#ffb13b")
val FWD = Color.parseColor("#3fd6c5")
val REV = Color.parseColor("#ff6b57")
val NEUTRAL = Color.parseColor("#aab4c0")

const val MIN_THRESHOLD = 50   // igual que el firmware (sobre 1023)

/** Mezcla a->b (t=0 es a, t=1 es b). */
fun mix(a: Int, b: Int, t: Float): Int {
    fun ch(x: Int, y: Int) = (x + (y - x) * t).roundToInt().coerceIn(0, 255)
    return Color.rgb(
        ch(Color.red(a), Color.red(b)),
        ch(Color.green(a), Color.green(b)),
        ch(Color.blue(a), Color.blue(b))
    )
}

/** map(x, -100, 100, -1023, 1023) con aritmetica entera, como en el firmware. */
fun arduinoMap(x: Int): Int = (x + 100) * 2046 / 200 - 1023

// ------------------------------------------------------- base de dibujo

abstract class InstrumentView(ctx: Context) : View(ctx) {
    protected val pt = Paint(Paint.ANTI_ALIAS_FLAG)
    protected val path = Path()
    private val rect = RectF()

    protected fun fill(c: Int) {
        pt.style = Paint.Style.FILL
        pt.color = c
        pt.pathEffect = null
    }

    protected fun stroke(c: Int, w: Float = 1f, dash: Boolean = false,
                         cap: Paint.Cap = Paint.Cap.BUTT) {
        pt.style = Paint.Style.STROKE
        pt.color = c
        pt.strokeWidth = w
        pt.strokeCap = cap
        pt.pathEffect = if (dash) DashPathEffect(floatArrayOf(2f, 4f), 0f) else null
    }

    protected fun rrect(c: Canvas, l: Float, t: Float, r: Float, b: Float, rad: Float) {
        rect.set(l, t, r, b)
        c.drawRoundRect(rect, rad, rad, pt)
    }

    protected fun text(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int,
                       align: Paint.Align = Paint.Align.LEFT, bold: Boolean = false) {
        pt.style = Paint.Style.FILL
        pt.pathEffect = null
        pt.color = color
        pt.textSize = size
        pt.textAlign = align
        pt.typeface = if (bold) Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        else Typeface.MONOSPACE
        c.drawText(s, x, y + size * 0.35f, pt)
    }
}

// ------------------------------------------------------------- boton

class PanelButton(
    ctx: Context,
    label: String,
    private var accent: Int,
    private val toggle: Boolean = false,
    private val action: () -> Unit
) : TextView(ctx) {

    var active = false

    init {
        text = label
        gravity = Gravity.CENTER
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        typeface = Typeface.DEFAULT_BOLD
        isClickable = true
        setOnClickListener {
            if (toggle) {
                active = !active
                refresh()
            }
            action()
        }
        refresh()
    }

    fun setLabel(t: String, color: Int? = null) {
        text = t
        if (color != null) accent = color
        refresh()
    }

    private fun shape(fill: Int, line: Int) = GradientDrawable().apply {
        cornerRadius = 14f
        setColor(fill)
        setStroke(2, line)
    }

    private fun refresh() {
        val sl = StateListDrawable()
        sl.addState(intArrayOf(android.R.attr.state_pressed),
            shape(INSET, mix(EDGE, accent, .85f)))
        val base = if (active) shape(mix(PANEL, accent, .26f), mix(EDGE, accent, .85f))
        else shape(mix(PANEL, accent, .07f), mix(EDGE, accent, .45f))
        sl.addState(intArrayOf(), base)
        background = sl
        setTextColor(if (active) accent else INK)
    }
}

// ----------------------------------------------------------- joystick

/** Analogico tactil. Solo el eje X maneja el motor (igual que la app). */
class JoystickView(
    ctx: Context,
    private val onChange: () -> Unit,
    private val onGrab: () -> Unit
) : InstrumentView(ctx) {

    private val S = 220f
    private val R = 66f
    private val c0 = S / 2

    @Volatile var axisX = 0f
        private set
    @Volatile var dragging = false
        private set
    private var visX = 0f
    private var visY = 0f
    private var springing = false
    private var scale = 1f

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        val s = MeasureSpec.getSize(widthSpec)
        setMeasuredDimension(s, s)
    }

    override fun onDraw(c: Canvas) {
        scale = width / S
        c.save()
        c.scale(scale, scale)

        fill(INSET); c.drawCircle(c0, c0, 96f, pt)
        stroke(EDGE, 1f); c.drawCircle(c0, c0, 96f, pt)
        for (deg in 0 until 360 step 10) {
            val a = Math.toRadians(deg.toDouble())
            val long = deg % 30 == 0
            val r0 = if (long) 84f else 89f
            val r1 = 94f
            stroke(mix(EDGE, INK, if (long) .45f else .15f), 1f)
            c.drawLine(c0 + r0 * cos(a).toFloat(), c0 + r0 * sin(a).toFloat(),
                c0 + r1 * cos(a).toFloat(), c0 + r1 * sin(a).toFloat(), pt)
        }
        stroke(EDGE, 1f, dash = true); c.drawCircle(c0, c0, 72f, pt)
        stroke(EDGE, 1f)
        c.drawLine(c0 - 72, c0, c0 + 72, c0, pt)
        c.drawLine(c0, c0 - 72, c0, c0 + 72, pt)
        text(c, "rev", 14f, S - 8, 9f, mix(PANEL, REV, .8f), Paint.Align.LEFT, true)
        text(c, "fwd", S - 14, S - 8, 9f, mix(PANEL, FWD, .8f), Paint.Align.RIGHT, true)

        val px = c0 + visX * R
        val py = c0 + visY * R
        val col = if (abs(visX) < 0.05f) NEUTRAL else if (visX > 0) FWD else REV
        stroke(mix(INSET, col, .55f), 3f, cap = Paint.Cap.ROUND)
        c.drawLine(c0, c0, px, py, pt)
        fill(mix(INSET, col, .10f)); c.drawCircle(px, py, 34f, pt)
        fill(mix(INSET, col, .20f)); c.drawCircle(px, py, 28f, pt)
        fill(mix(Color.parseColor("#10161c"), col, .30f)); c.drawCircle(px, py, 20f, pt)
        stroke(col, 2f); c.drawCircle(px, py, 20f, pt)
        fill(col); c.drawCircle(px, py, 5f, pt)

        c.restore()
    }

    private fun setFrom(e: MotionEvent) {
        var dx = e.x / scale - c0
        var dy = e.y / scale - c0
        val d = hypot(dx, dy)
        if (d > R) {
            dx = dx * R / d
            dy = dy * R / d
        }
        axisX = dx / R
        visX = dx / R
        visY = dy / R
        invalidate()
        onChange()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                onGrab()
                dragging = true
                springing = false
                setFrom(e)
            }
            MotionEvent.ACTION_MOVE -> if (dragging) setFrom(e)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragging = false
                axisX = 0f
                onChange()          // el cero sale de inmediato
                startSpring()
            }
        }
        return true
    }

    fun reset() {
        dragging = false
        axisX = 0f
        startSpring()
    }

    private val stepper = object : Runnable {
        override fun run() {
            visX *= 0.62f
            visY *= 0.62f
            if (abs(visX) < 0.01f && abs(visY) < 0.01f) {
                visX = 0f
                visY = 0f
                springing = false
            } else {
                postOnAnimation(this)
            }
            invalidate()
        }
    }

    private fun startSpring() {
        if (!springing) {
            springing = true
            postOnAnimation(stepper)
        }
    }
}

// ------------------------------------------------------------- fader

/** Fader vertical 10..100 en pasos de 5 (el 'Power Level' de la app). */
class PowerSliderView(
    ctx: Context,
    value: Int,
    private val onChange: (Int) -> Unit
) : InstrumentView(ctx) {

    private val DW = 90f
    private val DH = 320f
    private val TOP = 22f
    private val BOT = 298f
    private val X = 34f
    private val VMIN = 10
    private val VMAX = 100
    private val STEP = 5

    var value = value
        private set
    private var scale = 1f

    private fun yOf(v: Float) = BOT - (v - VMIN) / (VMAX - VMIN) * (BOT - TOP)

    override fun onDraw(c: Canvas) {
        scale = min(width / DW, height / DH)
        c.save()
        c.scale(scale, scale)

        fill(INSET); rrect(c, X - 5, TOP - 4, X + 5, BOT + 4, 3f)
        stroke(EDGE, 1f); rrect(c, X - 5, TOP - 4, X + 5, BOT + 4, 3f)
        for (v in VMIN..VMAX step STEP) {
            val y = yOf(v.toFloat())
            val major = v == 10 || v == 40 || v == 70 || v == 100
            stroke(if (major) INK else DIM, 1f)
            c.drawLine(X + 12, y, X + if (major) 28f else 20f, y, pt)
            if (major) text(c, v.toString(), X + 34, y, 10f, INK)
        }

        val y = yOf(value.toFloat())
        fill(mix(INSET, AMBER, .75f))
        c.drawRect(X - 3, y, X + 3, BOT, pt)
        fill(mix(PANEL, INK, .14f)); rrect(c, X - 19, y - 9, X + 19, y + 9, 3f)
        stroke(INK, 1f); rrect(c, X - 19, y - 9, X + 19, y + 9, 3f)
        stroke(AMBER, 2f); c.drawLine(X - 13, y, X + 13, y, pt)

        c.restore()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                fromTouch(e.y)
            }
            MotionEvent.ACTION_MOVE -> fromTouch(e.y)
        }
        return true
    }

    private fun fromTouch(ty: Float) {
        val dy = ty / scale
        val raw = VMIN + (BOT - dy) / (BOT - TOP) * (VMAX - VMIN)
        set((raw / STEP).roundToInt() * STEP)
    }

    fun set(v: Int) {
        val nv = v.coerceIn(VMIN, VMAX)
        if (nv != value) {
            value = nv
            invalidate()
            onChange(nv)
        }
    }
}

// ----------------------------------------------------------- galvanometro

/** Galvanometro de cero central: la aguja sigue al comando con inercia. */
class GaugeView(ctx: Context) : InstrumentView(ctx) {

    private val DW = 390f
    private val DH = 190f
    private val PX = 195f
    private val PY = 140f
    private val SWEEP = 55f

    private var pos = 0f
    private var vel = 0f
    private var target = 0

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        val w = MeasureSpec.getSize(widthSpec)
        setMeasuredDimension(w, (w * DH / DW).roundToInt())
    }

    private fun ptx(v: Float, r: Float) =
        PX + r * sin(Math.toRadians((v / 100.0 * SWEEP))).toFloat()

    private fun pty(v: Float, r: Float) =
        PY - r * cos(Math.toRadians((v / 100.0 * SWEEP))).toFloat()

    private fun arc(c: Canvas, a: Float, b: Float, r: Float, col: Int, w: Float) {
        path.reset()
        for (i in 0..40) {
            val v = a + (b - a) * i / 40f
            if (i == 0) path.moveTo(ptx(v, r), pty(v, r)) else path.lineTo(ptx(v, r), pty(v, r))
        }
        stroke(col, w)
        c.drawPath(path, pt)
    }

    /** masa-resorte subamortiguado (overshoot ~8 %): aguja de bobina movil. */
    fun advance(dt: Float, target: Int) {
        this.target = target
        val n = max(1, (dt / 0.004f).toInt())
        val h = dt / n
        repeat(n) {
            val acc = (target - pos) * 110f - vel * 13f
            vel += acc * h
            pos += vel * h
        }
        pos = pos.coerceIn(-106f, 106f)
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val s = width / DW
        c.save()
        c.scale(s, s)

        fill(INSET); rrect(c, 1f, 1f, DW - 1, DH - 1, 6f)
        stroke(EDGE, 1f); rrect(c, 1f, 1f, DW - 1, DH - 1, 6f)
        arc(c, -100f, 0f, 100f, mix(INSET, REV, .6f), 3f)
        arc(c, 0f, 100f, 100f, mix(INSET, FWD, .6f), 3f)
        arc(c, -5f, 5f, 100f, AMBER, 5f)            // zona muerta del firmware
        for (v in -100..100 step 5) {
            val major = v % 50 == 0
            val mid = v % 10 == 0
            val len = if (major) 11f else if (mid) 6f else 3f
            stroke(if (major) INK else DIM, 1f)
            c.drawLine(ptx(v.toFloat(), 105f), pty(v.toFloat(), 105f),
                ptx(v.toFloat(), 105f + len), pty(v.toFloat(), 105f + len), pt)
            if (major) text(c, v.toString(), ptx(v.toFloat(), 128f), pty(v.toFloat(), 128f),
                8f, DIM, Paint.Align.CENTER)
        }
        text(c, "Output x", 20f, 150f, 8f, DIM)

        val mapx = arduinoMap(target)
        val mode: String
        val col: Int
        val detail: String
        if (mapx > MIN_THRESHOLD) {
            mode = "Forward"; col = FWD; detail = "pwm $mapx/1023  dir low"
        } else if (mapx < -MIN_THRESHOLD) {
            mode = "Reverse"; col = REV; detail = "pwm 0  dir high"
        } else {
            mode = "Coast"; col = NEUTRAL; detail = "outputs low"
        }

        val th = Math.toRadians((pos / 100.0 * SWEEP))
        val dx = sin(th).toFloat()
        val dy = -cos(th).toFloat()
        val ox = cos(th).toFloat()
        val oy = sin(th).toFloat()
        path.reset()
        path.moveTo(PX + 98 * dx, PY + 98 * dy)
        path.lineTo(PX + 3 * ox, PY + 3 * oy)
        path.lineTo(PX - 16 * dx, PY - 16 * dy)
        path.lineTo(PX - 3 * ox, PY - 3 * oy)
        path.close()
        fill(INK); c.drawPath(path, pt)
        fill(PANEL); c.drawCircle(PX, PY, 8f, pt)
        stroke(INK, 2f); c.drawCircle(PX, PY, 8f, pt)
        fill(INK); c.drawCircle(PX, PY, 2f, pt)

        text(c, String.format(Locale.US, "%+d", target), 20f, 170f, 22f, AMBER, bold = true)
        text(c, mode, 104f, 170f, 11f, col, bold = true)
        text(c, detail, DW - 18, 170f, 9f, DIM, Paint.Align.RIGHT)

        c.restore()
    }
}

// ------------------------------------------------------------ lampara

class LampView(ctx: Context) : InstrumentView(ctx) {

    /** 0 = offline, 1 = enlace abierto, 2 = enlace verificado. */
    var state = 0
        set(v) {
            field = v
            invalidate()
        }
    private val labels = arrayOf("Offline", "Link open", "Link verified")

    override fun onDraw(c: Canvas) {
        val t = SystemClock.elapsedRealtime() / 1000.0
        val col = when (state) {
            0 -> REV
            1 -> AMBER
            else -> FWD
        }
        val on = state != 0
        val glow = (.12 + (if (on) .14 * (sin(t * 3) + 1) / 2 else 0.0)).toFloat()
        val u = height / 30f
        val cy = height / 2f
        fill(mix(CHASSIS, col, glow)); c.drawCircle(15 * u, cy, 13 * u, pt)
        fill(INSET); c.drawCircle(15 * u, cy, 8 * u, pt)
        stroke(EDGE, 1f); c.drawCircle(15 * u, cy, 8 * u, pt)
        fill(if (on) col else mix(INSET, col, .5f)); c.drawCircle(15 * u, cy, 5 * u, pt)
        text(c, labels[state], 36 * u, cy, height * 0.40f, INK)
    }
}
